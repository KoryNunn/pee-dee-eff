
    var a = document.createElement('a');

    a.textContent = 'HERP';

    window.onload = function(){
        document.body.appendChild(a);
    };
